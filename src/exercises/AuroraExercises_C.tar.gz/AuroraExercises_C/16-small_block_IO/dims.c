const int m = 1000;
const int n = 10;
const int o = 100;
const int iter = 1;
const double maxi = 5.0;
