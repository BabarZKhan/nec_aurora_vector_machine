#ifndef VEC_H
#define VEC_H
void do_comp_extensive(double* A, double* B);
void do_comp_boolmask(double* A, double* B, double* C, double* L);
void do_comp_indexlist(double* A, double* B, double* C, double* L);
#endif
