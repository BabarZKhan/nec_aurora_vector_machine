const int m = 8192;
const int n = 128;
const int o = 32;
const int iter = 25;
const double maxi = 5.0;
