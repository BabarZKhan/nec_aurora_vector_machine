const int m = 10000;
const int n = 100;
const int o = 500;
const double maxi = 5.0;
