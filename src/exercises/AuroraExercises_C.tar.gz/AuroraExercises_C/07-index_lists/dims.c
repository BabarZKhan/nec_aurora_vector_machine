const int m = 16384;
const int n = 1024;
const int iter = 1000;
const double maxi = 5.0;
