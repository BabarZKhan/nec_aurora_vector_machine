const int m = 32768;
const int n = 256;
const double maxi = 5.0;
const double minA = 1.0;
