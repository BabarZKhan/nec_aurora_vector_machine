#ifndef DIMS_H
#define DIMS_H
extern const int m;
extern const int n;
extern const double maxi;
extern const double minA;
#endif
