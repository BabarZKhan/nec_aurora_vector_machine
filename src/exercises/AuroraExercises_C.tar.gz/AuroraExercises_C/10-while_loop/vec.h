#ifndef VEC_H
#define VEC_H
void do_comp(double* A, double* B);
#endif
