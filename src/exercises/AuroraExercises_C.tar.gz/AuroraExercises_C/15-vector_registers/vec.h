#ifndef VEC_H
#define VEC_H
void do_comp1(double* A, double* C);
void do_comp2(double* B,double* C);
void do_comp3(double* E, double* F, double* B);
void do_comp4(double* A, double* B);
#endif
