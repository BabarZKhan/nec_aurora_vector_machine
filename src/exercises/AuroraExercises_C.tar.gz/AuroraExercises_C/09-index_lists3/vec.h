#ifndef VEC_H
#define VEC_H
void do_comp(double* A, double* B, int* ind1, int* ind2);
#endif
