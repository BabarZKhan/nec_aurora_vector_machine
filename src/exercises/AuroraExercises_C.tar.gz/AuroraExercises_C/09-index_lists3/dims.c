const int m = 9984;
const int n = 256;
const int iter = 1000;
const int l = 5;
const double maxi = 5.0;
