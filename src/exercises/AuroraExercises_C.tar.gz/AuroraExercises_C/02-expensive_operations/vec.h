#ifndef VEC_H
#define VEC_H
void do_comp1 (double* A, double* B);
void do_comp2 (double* A, double* B);
void do_comp3 (double* A, double* B);
void do_comp4 (double* A, double* B);
void do_comp5 (double* A, double* B);
void do_comp6 (double* A, double* B, double* C);
void do_comp7 (double* A, double* B);
#endif
