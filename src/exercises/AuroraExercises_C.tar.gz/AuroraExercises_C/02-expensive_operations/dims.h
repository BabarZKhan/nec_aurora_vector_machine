#ifndef DIMS_H
#define DIMS_H
extern const int n;
extern const int m;
extern const int o;
extern const int iter;
#endif
