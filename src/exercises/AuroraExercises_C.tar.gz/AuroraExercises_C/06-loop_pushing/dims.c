const int m = 512;
const int n = 256;
const int o = 10;
const int iter = 14;
