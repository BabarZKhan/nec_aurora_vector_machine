#ifndef DIMS_H
#define DIMS_H
extern const int l;
extern const int m;
extern const int n;
#endif
