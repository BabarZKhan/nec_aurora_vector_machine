#ifndef VEC_H
#define VEC_H
void do_comp(int m, int n, int o, double* A, double* B);
void do_comp_general(int m, int n, int o, double* A, double* B);
#endif
