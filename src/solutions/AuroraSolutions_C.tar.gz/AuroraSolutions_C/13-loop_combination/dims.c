const int m = 10000;
const int n = 100;
const int o = 10;
const int iter = 10000;
const double maxi = 5.0;
