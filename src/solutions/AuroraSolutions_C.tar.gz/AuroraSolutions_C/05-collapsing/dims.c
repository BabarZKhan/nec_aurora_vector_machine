const int l=11;
const int m=21;
const int n=31;
