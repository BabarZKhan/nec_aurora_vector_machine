#ifndef VEC_H
#define VEC_H
void init(double* a);
void sub1(double* a, double* b);
void sub2(double* a, double* b, int imax, int jmax, int kmax);
void sub3(double* a, double* b, int imax, int jmax, int kmax);
void sub4(double* a, double* b);
#endif
