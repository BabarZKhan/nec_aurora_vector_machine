#ifndef DIMS_H
#define DIMS_H
extern const int m;
extern const int n;
extern const int iter;
extern const int l;
extern const double maxi;
#endif
