#ifndef VEC_H
#define VEC_H
void do_comp_boolmask(double* A, double* B, double* C, int* L, char* ftraceident);
void do_comp_static_idxlist(double* A, double* B, double* C, int* L, char* ftraceident);
void do_comp_dynamic_idxlist(double* A, double* B, double* C, int* L, char* ftraceident);
#endif
