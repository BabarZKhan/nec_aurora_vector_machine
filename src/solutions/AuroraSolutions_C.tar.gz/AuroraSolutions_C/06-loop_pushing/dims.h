#ifndef DIMS_H
#define DIMS_H

int const m;
int const n;
int const o;
int const iter;

enum day {MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY};

#endif
