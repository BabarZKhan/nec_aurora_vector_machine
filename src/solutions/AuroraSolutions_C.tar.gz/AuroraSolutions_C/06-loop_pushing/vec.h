#ifndef VEC_H
#define VEC_H

#include "dims.h"
void do_loop(double* A, double* B, double* C, double* D, double* L,
             int today);

#endif
