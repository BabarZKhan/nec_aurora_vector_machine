#ifndef VEC_H
#define VEC_H
void do_comp_boolmask(double* A, double* B);
void do_comp_idxlist(double* A, double* B);
#endif
