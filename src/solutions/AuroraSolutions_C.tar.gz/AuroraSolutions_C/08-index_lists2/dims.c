const int m = 8192;
const int n = 256;
const int o = 256;
const int iter = 1;
const double maxi = 5.0;
